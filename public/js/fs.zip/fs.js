$(function(){
	$('.page a,.service_type a').click(function(){
		$(this).addClass('current').siblings().removeClass('current');
	});

	$('.zhedie .more').click(function(){
		$(this).removeClass('active').siblings().addClass('active');
		$('.hide').stop().slideToggle(300);
	})
	$('.area a').click(function(){
		$(this).addClass('current').siblings().removeClass('current');
		$('.hide a').removeClass('current');
	})
	$('.hide a').click(function(){
		$(this).addClass('current').siblings().removeClass('current');
		$('.area a').removeClass('current');
	})
})